class Adapter implements NewSystem {
  OldSystem oldSystem;

  // Constructor: give the object(oldsystem) to adpater
  Adapter(OldSystem oldSystem) {
    this.oldSystem = oldSystem;
  }

  // here implement the method of interface
  public String fetchNumber() {
    // here take the number fromold system and converted into string
    return String.valueOf(oldSystem.getNumber());
  }
}
