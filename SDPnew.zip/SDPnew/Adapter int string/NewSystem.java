interface NewSystem {
  String fetchNumber(); // newsystem want string (fetch number)
}
