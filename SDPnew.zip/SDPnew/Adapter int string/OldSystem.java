class OldSystem {
  public Integer getNumber() {
    return 100; // Returns number in Integer format
  }
}
