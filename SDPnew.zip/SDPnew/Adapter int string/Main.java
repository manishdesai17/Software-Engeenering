public class Main {
  public static void main(String[] args) {
    OldSystem old = new OldSystem(); // Old system'object
    NewSystem adapter = new Adapter(old); // adapter wrapped the old class
    System.out.println("Converted number: " + adapter.fetchNumber()); // Output
  }
}
