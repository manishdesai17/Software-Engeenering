public interface inputstream {
    int read();
}
