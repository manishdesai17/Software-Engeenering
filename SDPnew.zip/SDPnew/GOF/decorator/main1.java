public class main1 {
    public static void main(String[] args) {
        // Create a basic FileInputStream
        inputstream fileInputStream = new fileinputstream();

        // Wrap it with a LoggingInputStreamDecorator
        inputstream loggingInputStream = new logginginput(fileInputStream);

        // Use the decorated stream
        loggingInputStream.read(); // This will log and then read
    }
}
