public abstract class inputstreamdeco implements inputstream {
    protected inputstream wrappedInputStream;

    public inputstreamdeco(inputstream inputStream) {
        this.wrappedInputStream = inputStream;
    }

    public int read() {
        return wrappedInputStream.read();
    }
}
