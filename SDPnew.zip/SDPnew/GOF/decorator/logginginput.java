public class logginginput extends inputstreamdeco {
    
    public logginginput(inputstream inputStream) {
        super(inputStream);
    }

    public int read() {
        System.out.println("Logging: Reading a byte from the stream...");
        return super.read();
    }
}
