public class fileinputstream implements inputstream {

    public int read() {

        System.out.println("Reading a byte from the file...");
        return 0; 
    }
}
