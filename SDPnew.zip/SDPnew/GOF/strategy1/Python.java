public class Python extends Snake {
    public Python() {
        venomBehavior = new NonVenomousBehavior();
    }
    
    public void display() {
        System.out.println("I am a Python.");
    }
}
