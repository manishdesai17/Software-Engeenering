public class VenomousBehavior implements IVenomBehavior {
    
    public void venomType() {
        System.out.println("I am venomous.");
    }
}
