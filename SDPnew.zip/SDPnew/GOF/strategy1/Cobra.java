public class Cobra extends Snake {
    public Cobra() {
        venomBehavior = new VenomousBehavior();
    }

    public void display() {
        System.out.println("I am a Cobra.");
    }
}
