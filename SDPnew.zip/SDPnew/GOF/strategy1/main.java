public class main {
    public static void main(String[] args) {
        Snake cobra = new Cobra();
        cobra.display();
        cobra.showVenomType();

        System.out.println("-- Changing Cobra to non-venomous --");
        cobra.setVenomBehavior(new NonVenomousBehavior());
        cobra.showVenomType();

        Snake python = new Python();
        python.display();
        python.showVenomType();

        System.out.println("-- Changing Python to venomous --");
        python.setVenomBehavior(new VenomousBehavior());
        python.showVenomType();
    }
}
