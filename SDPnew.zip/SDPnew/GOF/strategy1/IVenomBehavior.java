public interface IVenomBehavior {
    void venomType();
}
