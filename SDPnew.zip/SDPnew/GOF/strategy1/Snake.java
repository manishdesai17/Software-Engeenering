public abstract class Snake {
    protected IVenomBehavior venomBehavior;

    public void setVenomBehavior(IVenomBehavior vb) {
        this.venomBehavior = vb;
    }

    public void showVenomType() {
        venomBehavior.venomType();
    }

    public abstract void display();
}
