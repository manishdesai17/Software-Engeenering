public class NonVenomousBehavior implements IVenomBehavior {
    
    public void venomType() {
        System.out.println("I am non-venomous.");
    }
}
