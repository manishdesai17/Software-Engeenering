import java.util.Scanner;

public class Main {
    public static void main(String argus[]){

        Scanner sc = new Scanner(System.in);

        A_factory factory = null;

        try{
            System.out.print("Enter your choice(indian ,chinese) :-");
            String dish = sc.next();
            //indian_factory f = indian_factory.getdish(dish);
            //Iappetizer mc =    f.createappetizer();
            //mc.serve();
            factory = A_factory.getfactory(dish);
            if(factory != null){

                Imaincourse mc = factory.createmaincourse();
            
                 System.out.println(mc.dish_name());
                //mc.dish_name();
                mc.serve();
                System.out.println("price :- " + mc.price());
                //mc.price();
            }
            
        }
        catch(IllegalArgumentException ex){
            ex.getMessage();    
        }
        finally{
            sc.close();
        }
    }    
}
