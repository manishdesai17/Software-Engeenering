public class chinese_maincourse implements Imaincourse{
    
    String dish;
    public chinese_maincourse(){
        dish = "Chinese MainCourse";
    }
    public String dish_name(){
        return dish;
    }
    public void serve(){
        System.out.println("Serving Chinese MainCourse Dish");
    }
    public double price(){
        return 670.00;
    }
}
