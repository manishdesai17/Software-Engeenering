public class indian_maincourse implements Imaincourse{
    
    String dish;
    public indian_maincourse(){
        dish = "Indian Maincourse";
    }
    public String dish_name(){
        return dish;
    }
    public void serve(){
        System.out.println("Serving Indian Maincourse Dish");
    }
    public double price(){
        return 400.00;
    }
}
