public class MB implements button{
    public void createcom(){
        System.out.println("button of MB created");
    }
}
