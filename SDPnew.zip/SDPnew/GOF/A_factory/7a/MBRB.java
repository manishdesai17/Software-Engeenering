public class MBRB implements radiobutton {
    public void createcom(){
        System.out.println("radiobutton of MB created");
    }
}
