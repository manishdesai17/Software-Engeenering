public class factory implements a_factory {

    public button createbutton(String type){
        button b = null;

        switch (type.toLowerCase()) {
            case "wb":
                b = new WB();
                break;
        
            case "lb":
                b = new LB();

            case "mb":
                b = new MB();
                break;

            default:
                throw new IllegalArgumentException("invalid");
        }
        return b;
    }

    public radiobutton createradiobutton(String type){
        radiobutton rb = null;

        switch (type.toLowerCase()) {
            case "wb":
                rb = new WBRB();
                break;
        
            case "lb":
                rb = new LBRB();

            case "mb":
                rb = new MBRB();
                break;

            default:
                throw new IllegalArgumentException("invalid");
        }
        return rb;
    }

    public checkbox createcheckbox(String type){
        checkbox cb = null;

        switch (type.toLowerCase()) {
            case "wb":
                cb = new WBCB();
                break;
        
            case "lb":
                cb = new LBCB();

            case "mb":
                cb = new MBCB();
                break;

            default:
                throw new IllegalArgumentException("invalid");
        }
        return cb;
    }
}
