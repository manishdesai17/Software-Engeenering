public class WBfactory implements a_factory {
    
    public button createbutton(String type){
        button b = null;

        b = new WB();

        return b;
    }
    public radiobutton createradiobutton(String type){
        radiobutton r = null;

        r = new WBRB();

        return r;
    }
    public checkbox createcheckbox(String type){
        checkbox c = null;

        c = new WBCB();

        return c;
    }
}

