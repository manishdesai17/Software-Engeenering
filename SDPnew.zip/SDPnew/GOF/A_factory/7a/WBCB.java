public class WBCB implements checkbox {
    public void createcom(){
        System.out.println("checkbox of WB created");
    }
}
