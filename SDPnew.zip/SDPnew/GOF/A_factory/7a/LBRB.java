public class LBRB implements radiobutton {
    public void createcom(){
        System.out.println("radiobutton of LB created");
    }
}
