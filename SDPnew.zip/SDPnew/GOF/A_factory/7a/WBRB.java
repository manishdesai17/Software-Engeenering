public class WBRB implements radiobutton {
    public void createcom(){
        System.out.println("radiobutton of WB created");
    }
}
