public interface a_factory {
    button createbutton(String type);
    radiobutton createradiobutton(String type);
    checkbox createcheckbox(String type);
}
