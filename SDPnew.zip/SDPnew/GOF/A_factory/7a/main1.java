import java.util.*;

public class main1 {
    public static void main(String args[]){

        Scanner sc = new Scanner(System.in);

        a_factory f = new WBfactory();

        System.out.println("Enter your choice(button,radiobutton,checkbox)");
        String choice = sc.next();

        System.out.println("Enter your choice(wb,lb,mb) :-");
        String type = sc.next();

        button b = null;
        //radiobutton r = null;
        try{
            b = f.createbutton(type);
           // r = f.createradiobutton(type);
            b.createcom();
           // r.createcom();
        }
        catch(IllegalArgumentException ex){
            System.out.println(ex.getMessage());
        }
    }
}

