public interface button {
    public void createcom();
}
