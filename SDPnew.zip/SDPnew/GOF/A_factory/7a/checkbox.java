public interface checkbox {
    public void createcom();
}
