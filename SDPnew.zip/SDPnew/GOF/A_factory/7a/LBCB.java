public class LBCB implements checkbox{
    public void createcom(){
        System.out.println("checkbox of LB created");
    }
}
