public class WB implements button {
    public void createcom(){
        System.out.println("button of WB created");
    }
}
