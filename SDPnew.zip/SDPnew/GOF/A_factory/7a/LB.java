public class LB implements button {
    public void createcom(){
        System.out.println("button of LB created");
    }
}
