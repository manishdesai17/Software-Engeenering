interface Iappetizer {
    String dish_name();
    void serve();
    double price();   
}