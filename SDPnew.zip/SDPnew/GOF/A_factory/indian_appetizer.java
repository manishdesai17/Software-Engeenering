public class indian_appetizer implements Iappetizer{
    
    String dish;
    public indian_appetizer(){
        dish = "Indian Appetizer";
    }
    public String dish_name(){
        return dish;
    }
    public void serve(){
        System.out.println("Serving Indian Appetizer Dish");
    }
    public double price(){
        return 100.00;
    }
}
