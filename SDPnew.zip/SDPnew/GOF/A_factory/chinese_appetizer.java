public class chinese_appetizer implements Iappetizer{
    
    String dish;
    public chinese_appetizer(){
        dish = "Chinese Appetizer";
    }
    public String dish_name(){
        return dish;
    }
    public void serve(){
        System.out.println("Serving Chinese Appetizer Dish");
    }
    public double price(){
        return 450.00;
    }
}
