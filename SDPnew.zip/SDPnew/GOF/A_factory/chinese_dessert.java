public class chinese_dessert implements Idessert{
    
    String dish;
    public chinese_dessert(){
        dish = "Chinese Dessert";
    }
    public String dish_name(){
        return dish;
    }
    public void serve(){
        System.out.println("Serving Chinese Dessert Dish");
    }
    public double price(){
        return 600.00;
    }
}
