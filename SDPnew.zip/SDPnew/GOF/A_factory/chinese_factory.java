public class chinese_factory implements A_factory {
    public Imaincourse createmaincourse(){
        return new chinese_maincourse();
    }

    public Iappetizer createappetizer(){
        return new chinese_appetizer();
    }

    public Idessert createdessert(){
        return new chinese_dessert();
    }
}
