interface Imaincourse {
    String dish_name();
    void serve();
    double price();   
}