public class indian_factory implements A_factory {
    public Imaincourse createmaincourse(){
        return new indian_maincourse();
    }

    public Iappetizer createappetizer(){
        return new indian_appetizer();
    }

    public Idessert createdessert(){
        return new indian_dessert();
    }

    public static indian_factory getdish(String dish){
        switch(dish.toLowerCase()){
            case "m" :
                indian_factory factory  = new indian_factory();
                Imaincourse mc =  factory.createmaincourse();
                mc.serve();
            default:
                throw new IllegalArgumentException("Please enter valid dish");
        }
    }

}
