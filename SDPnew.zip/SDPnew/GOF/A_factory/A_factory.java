interface A_factory {
    Imaincourse createmaincourse();
    Iappetizer createappetizer();
    Idessert createdessert();

    public static A_factory getfactory(String dish){
        switch(dish.toLowerCase()){
            case "indian" :
                return new indian_factory();
            case "chinese":
                return new chinese_factory();
            default:
                throw new IllegalArgumentException("Please enter valid dish");
        }
    }
}
