public class indian_dessert implements Idessert{
    
    String dish;
    public indian_dessert(){
        dish = "Indian Dessert";
    }
    public String dish_name(){
        return dish;
    }
    public void serve(){
        System.out.println("Serving Indian Dessert Dish");
    }
    public double price(){
        return 800.00;
    }
}
