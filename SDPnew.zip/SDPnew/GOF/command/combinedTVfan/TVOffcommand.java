class TVOffcommand implements Command {
    private TV tv;

    public TVOffcommand(TV tv) {
        this.tv = tv;
    }

    public String execute() {
        return tv.turnOff();
    }

    public String undo() {
        return tv.turnOn();
    }
}