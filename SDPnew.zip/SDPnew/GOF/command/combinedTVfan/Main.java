public class Main {
    public static void main(String[] args) {
        TV tv = new TV();
        Fan fan = new Fan();

        Command tvOn = new TVOncommand(tv);
        Command tvOff = new TVOffcommand(tv);
        Command fanOn = new FanOncommand(fan);
        Command fanOff = new FanOffcommand(fan);

        RemoteControl remote = new RemoteControl();

        remote.setCommand(tvOn);
        System.out.println(remote.pressButton());  
        System.out.println(remote.pressUndo());    

        remote.setCommand(tvOff);
        System.out.println(remote.pressButton());  
        System.out.println(remote.pressUndo());    


        remote.setCommand(fanOn);
        System.out.println(remote.pressButton());  
        System.out.println(remote.pressUndo());    

        remote.setCommand(fanOff);
        System.out.println(remote.pressButton());  
        System.out.println(remote.pressUndo());   
    }
}