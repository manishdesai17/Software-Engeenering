interface Command {
    String execute();
    String undo();
}