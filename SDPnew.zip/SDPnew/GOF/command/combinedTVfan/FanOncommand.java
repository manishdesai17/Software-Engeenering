class FanOncommand implements Command {
    private Fan fan;

    public FanOncommand(Fan fan) {
        this.fan = fan;
    }

    public String execute() {
        return fan.turnOn();
    }

    public String undo() {
        return fan.turnOff();
    }
}