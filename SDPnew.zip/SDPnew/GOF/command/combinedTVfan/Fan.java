class Fan {
    public String turnOn() {
        return "Fan is ON";
    }

    public String turnOff() {
        return "Fan is OFF";
    }
}