class TVOncommand implements Command {
    private TV tv;

    public TVOncommand(TV tv) {
        this.tv = tv;
    }

    public String execute() {
        return tv.turnOn();
    }

    public String undo() {
        return tv.turnOff();
    }
}