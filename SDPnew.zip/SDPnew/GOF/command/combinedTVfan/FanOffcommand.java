class FanOffcommand implements Command {
    private Fan fan;

    public FanOffcommand(Fan fan) {
        this.fan = fan;
    }

    public String execute() {
        return fan.turnOff();
    }

    public String undo() {
        return fan.turnOn();
    }
}
