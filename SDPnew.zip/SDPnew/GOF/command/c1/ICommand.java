interface ICommand {
    String execute();
    String undo();
}