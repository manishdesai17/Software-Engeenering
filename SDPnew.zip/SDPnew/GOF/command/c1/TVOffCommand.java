class TVOffCommand implements ICommand{
    private TV tv;

    public TVOffCommand(TV tv) {
        this.tv = tv;
    }

    public String execute() {
        return tv.turnOff();
    }

    public String undo() {
        return tv.turnOn();
    }
}
