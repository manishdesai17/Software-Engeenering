public class main1 {
    public static void main(String[] args) {
        TV tv = new TV();

        ICommand turnOn = new TVOnCommand(tv);
        ICommand turnOff = new TVOffCommand(tv);

        RemoteControl remote = new RemoteControl();

        remote.setCommand(turnOn);
        System.out.println(remote.pressButton());  
        System.out.println(remote.pressUndo());  

        remote.setCommand(turnOff);
        System.out.println(remote.pressButton());  
        System.out.println(remote.pressUndo());    
    }
}
