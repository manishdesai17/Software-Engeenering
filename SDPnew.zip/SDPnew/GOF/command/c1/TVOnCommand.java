class TVOnCommand implements ICommand{
    private TV tv;

    public TVOnCommand(TV tv) {
        this.tv = tv;
    }

    public String execute() {
        return tv.turnOn();
    }

    public String undo() {
        return tv.turnOff();
    }
}
