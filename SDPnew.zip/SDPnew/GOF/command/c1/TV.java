//Receiver

class TV {

    public String turnOn() {
        return "TV is ON";
    }
    
    public String turnOff() {
        return "TV is OFF";
    }

}
    
