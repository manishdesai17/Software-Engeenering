//Invoker

public class RemoteControl {
    private ICommand command;   

    public void setCommand(ICommand command) {
        this.command = command;
    }

    public String pressButton() {
        return command.execute();
    }

    public String pressUndo() {
        return command.undo();
    }
}
