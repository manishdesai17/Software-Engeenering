import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class TextEditorCommand {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            JFrame frame = new JFrame("Command Pattern Text Editor");
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(400, 300);
            frame.setLayout(new BorderLayout());

            JTextArea textArea = new JTextArea();
            frame.add(new JScrollPane(textArea), BorderLayout.CENTER);

            TextEditor editor = new TextEditor(textArea);
            CommandManager manager = new CommandManager();

            JPanel buttonPanel = new JPanel(new FlowLayout());

            JButton upperBtn = new JButton("UPPERCASE");
            upperBtn.addActionListener((ActionEvent e) ->
                manager.executeCommand(new UpperCaseCommand(editor))
            );

            JButton lowerBtn = new JButton("lowercase");
            lowerBtn.addActionListener((ActionEvent e) ->
                manager.executeCommand(new LowerCaseCommand(editor))
            );

            JButton undoBtn = new JButton("Undo");
            undoBtn.addActionListener((ActionEvent e) ->
                manager.undo()
            );

            JButton redoBtn = new JButton("Redo");
            redoBtn.addActionListener((ActionEvent e) ->
                manager.redo()
            );

            buttonPanel.add(upperBtn);
            buttonPanel.add(lowerBtn);
            buttonPanel.add(undoBtn);
            buttonPanel.add(redoBtn);

            frame.add(buttonPanel, BorderLayout.SOUTH);
            frame.setVisible(true);
        });
    }
}
