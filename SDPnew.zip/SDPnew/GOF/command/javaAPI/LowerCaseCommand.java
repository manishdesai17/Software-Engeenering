public class LowerCaseCommand implements Command {
    private TextEditor editor;
    private String backup;

    public LowerCaseCommand(TextEditor editor) {
        this.editor = editor;
    }

    public void execute() {
        backup = editor.getText();
        editor.toLowerCase();
    }

    public void undo() {
        editor.setText(backup);
    }
}
