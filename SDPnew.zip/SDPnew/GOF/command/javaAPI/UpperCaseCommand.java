public class UpperCaseCommand implements Command {
    private TextEditor editor;
    private String backup;

    public UpperCaseCommand(TextEditor editor) {
        this.editor = editor;
    }

    public void execute() {
        backup = editor.getText();
        editor.toUpperCase();
    }

    public void undo() {
        editor.setText(backup);
    }
}
