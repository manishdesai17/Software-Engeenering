//Receiver

import javax.swing.*;

public class TextEditor {
    private JTextArea textArea;

    public TextEditor(JTextArea textArea) {
        this.textArea = textArea;
    }

    public void toUpperCase() {
        textArea.setText(textArea.getText().toUpperCase());
    }

    public void toLowerCase() {
        textArea.setText(textArea.getText().toLowerCase());
    }

    public String getText() {
        return textArea.getText();
    }

    public void setText(String text) {
        textArea.setText(text);
    }
}
