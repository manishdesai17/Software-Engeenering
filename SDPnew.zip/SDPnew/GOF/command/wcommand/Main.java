public class Main {
    public static void main(String[] args) {
        TV tv = new TV();
        RemoteControl remote = new RemoteControl(tv);

        System.out.println(remote.pressOnButton());   // TV is ON
        System.out.println(remote.pressOffButton());  // TV is OFF
    }
}