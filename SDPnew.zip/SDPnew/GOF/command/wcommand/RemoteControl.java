class RemoteControl {
    private TV tv;

    public RemoteControl(TV tv) {
        this.tv = tv;
    }

    public String pressOnButton() {
        return tv.turnOn();
    }

    public String pressOffButton() {
        return tv.turnOff();
    }
}
