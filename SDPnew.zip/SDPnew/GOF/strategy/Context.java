package Strategy;

public class Context {

    public ISnake s;

    public Context(ISnake snake) {
        this.s = snake;
    }

    public void getType() {
        // System.out.println(s.behavior());
        System.out.println(s.behavior());
    }
}