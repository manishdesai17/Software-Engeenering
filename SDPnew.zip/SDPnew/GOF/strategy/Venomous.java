package Strategy;

public class Venomous implements ISnake {

    @Override
    public String behavior() {
        return "Venomous ! ";
    }
}