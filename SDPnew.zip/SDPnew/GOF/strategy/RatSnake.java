package Strategy;

class RatSnake extends NonVenomous {

    @Override
    public String behavior() {
        // TODO Auto-generated method stub
        return super.behavior() + " Rat Snake ";
    }
}