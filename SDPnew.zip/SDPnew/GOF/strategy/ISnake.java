package Strategy;

public interface ISnake {

    public String behavior();
}