package Strategy;

public class main {

    public static void main(String[] args) {
        Context s = new Context(new RatSnake());
        s.getType();
    }
}