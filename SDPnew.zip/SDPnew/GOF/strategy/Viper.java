package Strategy;

class Viper extends Venomous {

    @Override
    public String behavior() {
        // TODO Auto-generated method stub
        return super.behavior() + " Viper ";
    }
}