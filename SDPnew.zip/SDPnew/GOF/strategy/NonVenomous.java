package Strategy;

public class NonVenomous implements ISnake {

    @Override
    public String behavior() {
        return "Non Venomous ! ";
    }
}