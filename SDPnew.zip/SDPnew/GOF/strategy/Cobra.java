package Strategy;

class Cobra extends Venomous {

    @Override
    public String behavior() {
        // TODO Auto-generated method stub
        return super.behavior() + " Cobra ";
    }
}