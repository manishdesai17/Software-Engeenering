import java.sql.Connection;

public class main1 {
    public static void main(String[] args) {

        DatabaseConManager db = DatabaseConManager.getInstance();
        // System.out.println();

        Connection connection = db.getConnection();
    }
}
