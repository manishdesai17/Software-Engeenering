import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConManager {
    private static DatabaseConManager instance;
    private Connection connection = null;

    private final String URL = "jdbc:mysql://localhost:3333/gvp_tanvi";
    private final String USERNAME = "gvp_tanvi";
    private final String PASSWORD = "455445";

    private DatabaseConManager() {

        try {
            // Class.forName("com.mysql.cj.jdbc.Driver"); // Load MySQL driver
            connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RuntimeException("Database connection failed!");
        }
    }

    public static synchronized DatabaseConManager getInstance() {
        if (instance == null) {
            instance = new DatabaseConManager();
        }
        return instance;
    }

    public Connection getConnection() {
        // System.out.println("database connected..");
        return connection;
    }

    public void closeConnection() {
        try {
            if (connection != null) {
                connection.close();
                instance = null;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}