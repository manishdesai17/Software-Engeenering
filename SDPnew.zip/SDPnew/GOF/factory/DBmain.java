import java.util.Scanner;

public class DBmain {
    public static void main(String[] args) {
        
    
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter Your Choice(mysql,mssql,mongodb,postgresql) :-");
        String dbType = sc.next();

        DBconnection db = null;

    try{
        db = DBfactory.dbconnection(dbType);
        System.out.println(db.Connect());
        System.out.println(db.Disconnect());
        System.out.println(db.Query());
    }
    catch(IllegalArgumentException ex){
        System.out.println(ex.getMessage());

    }    
    finally{
        sc.close();
    }
    }   
}
