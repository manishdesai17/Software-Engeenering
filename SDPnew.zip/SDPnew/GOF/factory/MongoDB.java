public class MongoDB implements DBconnection {
    private String connect,disconnect,query;
    
    public MongoDB(String connect,String disconnect,String query){
        this.connect = connect;
        this.disconnect = disconnect;
        this.query = query;
    }

    public String Connect(){
        return connect;
    }

    public String Disconnect(){
        return disconnect;
    }

    public String Query(){
        return query;
    }
}
