public interface DBconnection {

    public String Connect();

    public String Disconnect();

    public String Query();
}