public class DBfactory {
    public static DBconnection dbconnection(String dbType){

        DBconnection db = null;

        switch (dbType) {
            case "mysql":
                db = new mySQL("mysql connection", "mysql disconnection", "Select *from user;");
                break;
        
            case "postgresql":
                db = new PostGreSQL("postgresql connection","postgresql disconnection","poastgresql query");
                break;
            
            case "mssql":
                db = new MsSQL("mssql connection", "mysql disconnection", "mssql query");
                break;

            case "mongodb":
                db = new PostGreSQL("mongodb connection", "mongodb disconnection", "mongodb query");
                break;

            default:
                throw new IllegalArgumentException("invalid DataBase" + dbType);
        }
        return db;
    }
}