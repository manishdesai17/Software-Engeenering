import java.io.FileInputStream;
import java.io.IOException;

// Concrete Component - MyFileInputStream
public class fileIS implements inputstream {
    private FileInputStream fileInputStream;

    public fileIS(String filename) throws IOException {
        this.fileInputStream = new FileInputStream(filename);
    }

    public int read() throws IOException {
        return fileInputStream.read(); // Read a byte from file
    }
}
