import java.io.IOException;

public interface inputstream {
    int read() throws IOException;
}
