import java.io.IOException;

// Concrete Decorator that counts characters, words, and lines
public class countingISD extends decorator {
    private int characterCount = 0;
    private int wordCount = 0;
    private int lineCount = 0;
    private boolean inWord = false;

    public countingISD(inputstream inputStream) {
        super(inputStream);
    }

    public int read() throws IOException {
        int byteRead = wrappedInputStream.read();

        if (byteRead == -1) {
            return -1; // End of stream
        }

        // Convert byte to character
        char ch = (char) byteRead;
        characterCount++;

        // Count words and lines
        if (Character.isWhitespace(ch)) {
            if (inWord) {
                wordCount++;
                inWord = false;
            }
            if (ch == '\n') {
                lineCount++;
            }
        } else {
            inWord = true;
        }

        return byteRead;
    }

    public void printStats() {
        System.out.println("Character count: " + characterCount);
        System.out.println("Word count: " + wordCount);
        System.out.println("Line count: " + lineCount);
    }
}
