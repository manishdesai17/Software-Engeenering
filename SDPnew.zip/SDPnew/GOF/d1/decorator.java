import java.io.IOException;

// Abstract Decorator class - InputStreamDecorator
public abstract class decorator implements inputstream {
    protected inputstream wrappedInputStream;

    public decorator(inputstream inputStream) {
        this.wrappedInputStream = inputStream;
    }

    public int read() throws IOException {
        return wrappedInputStream.read();
    }
}
