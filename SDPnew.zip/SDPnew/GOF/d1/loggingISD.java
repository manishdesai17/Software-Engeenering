import java.io.IOException;

// Concrete Decorator that logs the bytes being read
public class loggingISD extends decorator {

    public loggingISD(inputstream inputStream) {
        super(inputStream);
    }

    public int read() throws IOException {
        int byteRead = wrappedInputStream.read();
        System.out.println("Byte read: " + byteRead);
        return byteRead;
    }
}
