import java.io.IOException;

public class main1 {
    public static void main(String[] args) {
        try {
            // Create a base FileInputStream
            inputstream fileInputStream = new fileIS("test.txt");

            // Wrap it with a LoggingInputStreamDecorator to log the bytes being read
            inputstream loggingInputStream = new loggingISD(fileInputStream);

            // Wrap it with a CountingInputStreamDecorator to count characters, words, and lines
            countingISD countingInputStream = new countingISD(loggingInputStream);

            // Read through the stream
            while (countingInputStream.read() != -1) {
                // Continue reading until EOF
            }

            // Print statistics (characters, words, lines)
            countingInputStream.printStats();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
