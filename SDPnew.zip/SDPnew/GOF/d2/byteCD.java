import java.io.IOException;
import java.io.InputStream;

public class byteCD extends decorator {
    private int byteCount = 0;

    public byteCD(inputstream fileInputStream) {
        super(fileInputStream);   
    }

    public int read() throws IOException {
        int byteRead = wrappedInputStream.read();
        if (byteRead == -1) {
            return -1;
        }
        byteCount++;
        System.out.println("Byte read: " + byteRead); 
        return byteRead;
    }

    public int getByteCount() {
        return byteCount;
    }
}
