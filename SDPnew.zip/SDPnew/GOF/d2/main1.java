import java.io.FileInputStream;
import java.io.IOException;

public class main1 {
    public static void main(String[] args) {
        try {

            inputstream fileInputStream = new fileIS("test.txt");

            byteCD byteCount = new byteCD(fileInputStream);

            int data;

            while ((data = fileInputStream.read()) != -1) {
                byteCount.getByteCount();
                System.out.print((char) data);  
            }

           // fileInputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
