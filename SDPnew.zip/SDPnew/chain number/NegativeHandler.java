public class NegativeHandler extends NumberHandler {
  @Override
  public void handle(int number) {
    if (number < 0) {
      System.out.println("Handled by NegativeHandler: " + number);
    } else if (next != null) {
      next.handle(number);
    }
  }
}
