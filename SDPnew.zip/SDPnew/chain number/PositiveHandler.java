public class PositiveHandler extends NumberHandler {
  @Override
  public void handle(int number) {
    if (number > 0) {
      System.out.println("Handled by PositiveHandler: " + number);
    } else if (next != null) {
      next.handle(number);
    }
  }
}
