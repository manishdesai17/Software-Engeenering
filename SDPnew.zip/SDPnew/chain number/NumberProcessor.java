public class NumberProcessor {
  public static void main(String[] args) {
    // Create handlers
    NumberHandler positive = new PositiveHandler();
    NumberHandler negative = new NegativeHandler();
    NumberHandler zero = new ZeroHandler();

    // Set up the chain
    positive.setNext(negative);
    negative.setNext(zero);

    // Test numbers
    int[] numbers = { 10, -5, 0, 7, -99, 0 };

    for (int num : numbers) {
      positive.handle(num); // Start from first handler
    }
  }
}
