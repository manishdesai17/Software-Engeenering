public class ZeroHandler extends NumberHandler {
  @Override
  public void handle(int number) {
    if (number == 0) {
      System.out.println("Handled by ZeroHandler: " + number);
    } else if (next != null) {
      next.handle(number);
    }
  }
}
