public abstract class NumberHandler {
  protected NumberHandler next;

  public void setNext(NumberHandler next) {
    this.next = next;
  }

  public abstract void handle(int number);
}
