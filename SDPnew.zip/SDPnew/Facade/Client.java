
public class Client {
    public static void main(String[] args) {
        FoodOrderFacade app = new FoodOrderFacade();
        app.placeOrder();
    }
    
}
