 class FoodOrderFacade {
    public Restaurant restaurant;
    public DeliveryService delivery;
    public PaymentGateway payment;
    
    public FoodOrderFacade(){
        restaurant = new Restaurant();
        delivery = new DeliveryService();
        payment = new PaymentGateway();
    }
    
    public void placeOrder(){
        System.out.println("Placing food order");
        restaurant.prepareOrder();
        delivery.assignDeliveryPerson();
        payment.processPayment();
        
        System.out.println("Order Placed Successfully");
    }
}
