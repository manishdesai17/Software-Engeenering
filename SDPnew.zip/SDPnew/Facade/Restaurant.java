class Restaurant {
    public String prepareOrder()
    {
        return "Restaurant: preparing the food";
    }
}
