class DeliveryService {
    public String assignDeliveryPerson()
    {
        return "Delivery : assigning delivery person";
    }
}
