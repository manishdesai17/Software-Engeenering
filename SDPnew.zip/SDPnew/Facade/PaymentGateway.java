class PaymentGateway {
    public String processPayment()
    {
        return "Payment: processing Payment";
    }
}
