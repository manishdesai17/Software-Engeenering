public class ChocolateSyrupDecorator extends IceCreamDecorator {

    public ChocolateSyrupDecorator(IceCream iceCream) {
        super(iceCream);
    }

    @Override
    public String getDescription() {
        return decoratedIceCream.getDescription() + " with Chocolate Syrup";
    }

    @Override
    public double cost() {
        return decoratedIceCream.cost() + 2.0; // Add cost of chocolate syrup
    }
}
