public class SprinklesDecorator extends IceCreamDecorator {

    public SprinklesDecorator(IceCream iceCream) {
        super(iceCream);
    }

    @Override
    public String getDescription() {
        return decoratedIceCream.getDescription() + " with Sprinkles";
    }

    @Override
    public double cost() {
        return decoratedIceCream.cost() + 1.5; // Add cost of sprinkles
    }
}
