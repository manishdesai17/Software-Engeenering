public abstract class IceCreamDecorator implements IceCream {
    protected IceCream decoratedIceCream;

    public IceCreamDecorator(IceCream iceCream) {
        this.decoratedIceCream = iceCream;
    }

    public String getDescription() {
        return decoratedIceCream.getDescription();
    }

    public double cost() {
        return decoratedIceCream.cost();
    }
}
