import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        IceCream iceCream = new PlainIceCream();

        System.out.println("Available toppings:");
        System.out.println("1. Chocolate Syrup (2.0)");
        System.out.println("2. Sprinkles (1.5)");
        System.out.println("3. Plain Ice Cream");
        System.out.println("Select toppings ");
        String input = scanner.nextLine();

        // Using switch-case to add toppings based on user input
        String[] choices = input.split(",");
        for (String choice : choices) {
            switch (choice.trim()) {
                case "1":
                    iceCream = new ChocolateSyrupDecorator(iceCream);
                    break;
                case "2":
                    iceCream = new SprinklesDecorator(iceCream);
                    break;
                
            }
        }

        System.out.println("Your Choice Is : " + iceCream.getDescription());
        System.out.println("Total cost: Rs " + iceCream.cost());

        scanner.close();
    }
}
