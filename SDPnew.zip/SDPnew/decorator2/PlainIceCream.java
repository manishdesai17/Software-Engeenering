public class PlainIceCream implements IceCream {

    @Override
    public String getDescription() {
        return "Plain Ice Cream ";
    }

    @Override
    public double cost() {
        return 5.0; // Base cost of plain ice cream
    }
}
