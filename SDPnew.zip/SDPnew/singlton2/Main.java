
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.SQLException;

public class Main {
    public static void main(String[] args) throws SQLException {
        DatabaseConnectionManager dbManager = null;
        Connection con = null;

        // Build the Connection
        dbManager = DatabaseConnectionManager.getDbConnectionManager();
        con = dbManager.getConnection();

        if (con != null) {
            System.out.println("Database connection established Successfully!");
        } else {
            System.out.println("Failed to establish database connection.");
        }

        // Close the Connection
        dbManager.closeConnection();
    }
}
