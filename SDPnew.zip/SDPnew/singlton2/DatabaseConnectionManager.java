/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnectionManager {
    static private DatabaseConnectionManager dbManager = null;
    private Connection con = null;

    // Private constructor to instantiation
    private DatabaseConnectionManager() throws SQLException {
        con = DriverManager.getConnection("jdbc:mysql://localhost:3333/gvp_tanvi","root" ,"455445");
    }

    // method to retrieve the single instance of DatabaseConnectionManager
    public static synchronized DatabaseConnectionManager getDbConnectionManager() throws SQLException {
        if (dbManager == null) {
            dbManager = new DatabaseConnectionManager();
        }

        return dbManager;
    }

    // Method to return the connection instance
    public Connection getConnection() {

        return con;
    }

    // Method to close the connection
    public void closeConnection() {
        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
            System.err.println("Error connection close: " + e.getMessage());
        }
    }
}