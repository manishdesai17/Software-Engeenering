
public class Trafficlc {
    AState state;

    void setState(AState state) {
        this.state = state;
    }

    void changeState() {
        if (state instanceof Cred) {
            state.getdetail();
            setState(new Cgreen());
        } else if (state instanceof Cgreen) {
            state.getdetail();
            setState(new Cyellow());
        } else if (state instanceof Cyellow) {
            state.getdetail();
            setState(new Cred());
        }

    }

}
