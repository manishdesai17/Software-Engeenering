
public class Cyellow extends AState {

    // Trafficlc t=new Trafficlc();
    @Override
    void getdetail() {
        System.out.println("yellow");
        // t.setState(new Cred());

    }

}
