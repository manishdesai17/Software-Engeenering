
public class Main {

    public static void main(String[] args) {
        Trafficlc context = new Trafficlc();
        context.setState(new Cred());
        context.changeState();
        context.changeState();
        context.changeState();
        context.changeState();
        context.changeState();
        context.changeState();
        context.changeState();

    }

}
