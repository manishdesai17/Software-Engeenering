
public class Cgreen extends AState {
    @Override
    void getdetail() {
        System.out.println("green");
        // t.setState(new Cyellow());

    }

}
