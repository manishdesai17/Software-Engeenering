
public class Cred extends AState {
    @Override
    void getdetail() {
        System.out.println("red");
        // t.setState(new Cgreen());
    }

}
