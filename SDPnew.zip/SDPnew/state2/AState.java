
public abstract class AState {
    abstract void getdetail();

}
