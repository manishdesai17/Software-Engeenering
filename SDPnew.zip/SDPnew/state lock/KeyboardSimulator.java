public class KeyboardSimulator {
  public static void main(String[] args) {
    LockKey capsLock = new LockKey("Caps Lock");
    LockKey numLock = new LockKey("Num Lock");
    LockKey scrollLock = new LockKey("Scroll Lock");

    // Simulate some user interactions
    capsLock.press(); // ON
    capsLock.press(); // OFF
    numLock.press(); // ON
    scrollLock.press(); // ON
    scrollLock.press(); // OFF
  }
}
