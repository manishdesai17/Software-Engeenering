public class OffState implements KeyState {
  @Override
  public void press(LockKey key) {
    System.out.println(key.getName() + " is now ON.");
    key.setState(new OnState());
  }
}
