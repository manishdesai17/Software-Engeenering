public interface KeyState {
  void press(LockKey key);
}
