public class OnState implements KeyState {
  @Override
  public void press(LockKey key) {
    System.out.println(key.getName() + " is now OFF.");
    key.setState(new OffState());
  }
}
