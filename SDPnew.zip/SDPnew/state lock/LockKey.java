public class LockKey {
  private String name;
  private KeyState state;

  public LockKey(String name) {
    this.name = name;
    this.state = new OffState(); // Default state is OFF
  }

  public void press() {
    state.press(this);
  }

  public void setState(KeyState state) {
    this.state = state;
  }

  public String getName() {
    return name;
  }
}
