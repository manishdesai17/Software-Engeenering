public interface DirectoryOperations {
    void createDirectory(String directoryName);
    void renameDirectory(String oldName, String newName);
    void deleteDirectory(String directoryName);
}
