
import java.io.File;


public class RealDirectoryOperations implements DirectoryOperations {

    //Create the directory
    @Override
    public void createDirectory(String directoryName) {
        File directory = new File(directoryName);
        if (directory.exists()) {
            System.out.println("Directory " + directoryName + " exists");
        } else {
            if (directory.mkdir()) {
                System.out.println("Directory " + directoryName + " created successfully");
            } else {
                System.out.println("Failed to create directory " + directoryName + ". ");
            }
        }
    }

    // Rename the Directory
    @Override
    public void renameDirectory(String oldName, String newName) {
        File oldDirectory = new File(oldName);
        File newDirectory = new File(newName);
        if (oldDirectory.exists()) {
            if (oldDirectory.renameTo(newDirectory)) {
                System.out.println("Directory renamed from '" + oldName + "' to '" + newName + "'.");
            } else {
                System.out.println("Failed to rename directory.");
            }
        } else {
            System.out.println("Directory '" + oldName + "' does not exist.");
        }
    }

    //delete the directory
    @Override
    public void deleteDirectory(String directoryName) {
        File directory = new File(directoryName);
        if (directory.exists()) {
            if (directory.delete()) {
                System.out.println("Directory '" + directoryName + "' deleted successfully.");
            } else {
                System.out.println("Directory '" + directoryName + "' is not empty, cannot delete.");
            }
        } else {
            System.out.println("Directory '" + directoryName + "' does not exist.");
        }
    }
}
