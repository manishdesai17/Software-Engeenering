
public class DirectoryProxy implements DirectoryOperations {

    private String userRole;
    private RealDirectoryOperations realOperations;

    public DirectoryProxy(String userRole) {
        this.userRole = userRole;
        this.realOperations = new RealDirectoryOperations();
    }

    @Override
    public void renameDirectory(String oldName, String newName) {
        if ("admin".equalsIgnoreCase(userRole)) {
            System.out.println("Admin has permission to rename the Directory.");
            realOperations.renameDirectory(oldName, newName);
        } else {
            System.out.println("User does not have Permission to name a directory.");
        }
    }

    @Override
    public void createDirectory(String directoryName) {
        if ("admin".equalsIgnoreCase(userRole)) {
            System.out.println("Admin has permission to create the directory.");
            realOperations.createDirectory(directoryName);
        } else {
            System.out.println("User does not have permission to create a directory.");
        }
    }

    @Override
    public void deleteDirectory(String directoryName) {
        if ("admin".equalsIgnoreCase(userRole)) {
            System.out.println("Admin has permission to delete the directory.");
            realOperations.deleteDirectory(directoryName);
        } else {
            System.out.println("User does not have permission to delete a directory.");
        }
    }

}
