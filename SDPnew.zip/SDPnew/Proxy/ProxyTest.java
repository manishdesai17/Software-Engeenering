
public interface ProxyTest {

    public static void main(String[] args) {
//        // Test as Admin
        System.out.println("Testing as Admin:");
        DirectoryOperations adminProxy = new DirectoryProxy("admin");
//        adminProxy.createDirectory("admin_folder");
//        adminProxy.renameDirectory("admin_folder", "admin_folder_renamed");
//        adminProxy.deleteDirectory("admin_folder_renamed");
        adminProxy.createDirectory("student");
        adminProxy.deleteDirectory("student");
        adminProxy.createDirectory("C:\\Sem-2\\204-SDP\\204-Assignment\\Proxy design pattern\\pooja");
        

//        // Test as User
//        System.out.println("\nTesting as User:");
//        DirectoryOperations userProxy = new DirectoryProxy("user");
//        userProxy.createDirectory("user_folder");  // User cannot create directories
//        userProxy.renameDirectory("user_folder", "user_folder_renamed");  // User cannot rename directories
//        userProxy.deleteDirectory("user_folder_renamed");  // User cannot delete directories
    }
}
