public class MySQL implements DatabaseConnection {
    @Override
    public void connect() {
        System.out.println("Connected to MySQL Database");
    }

    @Override
    public void disconnect() {
        System.out.println("Connection is Closed");
    }
}
