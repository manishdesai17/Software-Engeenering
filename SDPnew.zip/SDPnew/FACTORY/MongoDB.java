public class MongoDB implements DatabaseConnection {
    @Override
    public  void connect() {
        System.out.println("Connected to MongoDB Database");
    }

    @Override
    public void disconnect() {
        System.out.println("Connection is Closed");
    }
}
