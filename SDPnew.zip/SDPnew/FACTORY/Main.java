import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the type of database (MySQL, MsSQL, PostgreSQL, MongoDB): ");
        String dbType = sc.next();

        try {
            // Build the Connection
            DatabaseConnection con = DatabaseFactory.getDatabaseConnection(dbType);
            con.connect();

            // Disconnect the Database Connection
            con.disconnect();
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }

        sc.close();
    }
}
