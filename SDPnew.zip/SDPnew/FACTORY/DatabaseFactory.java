public class DatabaseFactory {
    public static DatabaseConnection getDatabaseConnection(String dbType) {
        switch (dbType.toLowerCase()) {
            case "mysql":
                return new MySQL();
            case "postgresql":
                return new PostgreSQL();
            case "mongodb":
                return new MongoDB();
            default:
                throw new IllegalArgumentException("Unsupported Database: " + dbType);
        }
    }
}
