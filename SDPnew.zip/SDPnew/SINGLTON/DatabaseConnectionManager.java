import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnectionManager {
    static private DatabaseConnectionManager dbManager = null;
    private Connection con = null;

    // Private constructor to instantiation
    private DatabaseConnectionManager() {
        System.out.println("Connected.............");
        // try {
        // con = DriverManager.getConnection("jdbc:mysql://localhost:3333/gvp_tanvi",
        // "root", "455445");
        // } catch (SQLException e) {
        // System.err.println("Error connecting to the database: " + e);
        // }
    }

    // method to retrieve the single instance of DatabaseConnectionManager
    public static synchronized DatabaseConnectionManager getDbConnectionManager() {
        if (dbManager == null) {
            dbManager = new DatabaseConnectionManager();
        }

        return dbManager;
    }

    // Method to return the connection instance
    public Connection getConnection() {

        return con;
    }

    // Method to close the connection
    public void closeConnection() {
        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException e) {
            System.err.println("Error connection close: " + e.getMessage());
        }
    }
}