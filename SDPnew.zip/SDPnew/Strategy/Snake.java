public abstract class Snake {
    private String name;  
    private Nature nature;         

    // Constructor initializes with SnakeType and dynamically sets the nature
    public Snake(String name, Nature nature) {
        this.name=name;
           this.nature=nature;
    }

    public void displayinfo()
    {
        System.out.println("Snake: " + name);
        System.out.println(nature.isPoisonous());
    }

    // Method to change SnakeType dynamically
    public void setNature(Nature nature) {
        this.nature = nature;
    }

}

