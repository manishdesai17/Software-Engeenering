
public class Cobra extends Snake {
    public Cobra(String name, Nature nature)
    {
        super(name,nature);
    }
    
}
