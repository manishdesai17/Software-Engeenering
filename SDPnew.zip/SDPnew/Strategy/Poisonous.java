public class Poisonous implements Nature {
    @Override
    public String isPoisonous() {
        return "the snake is poisonous...";
    }
}

