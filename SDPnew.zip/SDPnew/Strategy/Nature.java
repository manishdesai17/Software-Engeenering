
public interface Nature {

    String isPoisonous();
}
