
public class Strategy {
    public static void main(String[] args)
    {
        Snake python = new Python("Python",new NonPoisonous());
        Snake viper =  new Viper("Viper", new Poisonous());
        Snake cobra = new Cobra("Cobra" , new Poisonous());
        
        
        viper.displayinfo();
        
        //changing python behaviour
        viper.setNature(new Poisonous());
        viper.displayinfo();
    }
}
