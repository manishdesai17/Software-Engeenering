
public class Viper extends Snake {
    public Viper(String name, Nature nature)
    {
        super(name,nature);
    }
    
}
