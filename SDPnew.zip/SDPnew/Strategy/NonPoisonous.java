public class NonPoisonous implements Nature {
    @Override
    public String isPoisonous() {
        return "the snake is not poisonous...";
    }
}
