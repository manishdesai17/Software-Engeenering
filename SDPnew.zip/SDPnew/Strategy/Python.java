public class Python extends Snake {
    public Python(String name, Nature nature)
    {
        super(name,nature);
    }
    
}

