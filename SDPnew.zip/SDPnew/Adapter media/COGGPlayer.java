class COGGPlayer implements IAdvancedMediaPlayer {
    @Override
    public void playOGG(String fileName) {
        System.out.println("Playing OGG file: " + fileName);
    }

    @Override
    public void playFLAC(String fileName) {
        // Not applicable for OGGPlayer
    }
}