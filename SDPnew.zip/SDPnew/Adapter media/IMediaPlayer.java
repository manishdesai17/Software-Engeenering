interface IMediaPlayer 
{
    void play(String audioType, String fileName);
}



















