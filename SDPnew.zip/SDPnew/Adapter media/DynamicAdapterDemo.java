import java.util.Scanner;

// OGGPlayer implementation


// FLACPlayer implementation


// Adapter class to integrate AdvancedMediaPlayer with MediaPlayer


// AudioPlayer class to use the adapter

// Main application to interact with the user dynamically
public class DynamicAdapterDemo {
    public static void main(String[] args) {
        AudioPlayer player = new AudioPlayer();
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the Media Player!");
        System.out.println("Supported audio types: mp3, ogg, flac");

        while (true) {
            System.out.print("\nEnter the audio type (or 'exit' to quit): ");
            String audioType = scanner.nextLine();
            if (audioType.equalsIgnoreCase("exit")) {
                System.out.println("Exiting Media Player. Goodbye!");
                break;
            }

            System.out.print("Enter the file name: ");
            String fileName = scanner.nextLine();

            // Play the audio file
            player.play(audioType, fileName);
        }

        scanner.close();
    }
}
