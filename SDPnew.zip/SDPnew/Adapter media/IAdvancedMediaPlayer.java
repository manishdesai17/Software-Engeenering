interface IAdvancedMediaPlayer {
    void playOGG(String fileName);
    void playFLAC(String fileName);
}