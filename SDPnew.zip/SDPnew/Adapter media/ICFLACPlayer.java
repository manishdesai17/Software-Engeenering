class CFLACPlayer implements IAdvancedMediaPlayer {
    @Override
    public void playOGG(String fileName) {
        // Not applicable for FLACPlayer
    }

    @Override
    public void playFLAC(String fileName) {
        System.out.println("Playing FLAC file: " + fileName);
    }
}