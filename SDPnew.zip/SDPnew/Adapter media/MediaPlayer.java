
import java.util.Scanner;

public class MediaPlayer {

    // Method to play MP3 files
    public void playMP3(String filePath) {
        System.out.println("Playing MP3 file: " + filePath);
    }

    // Method to play OGG files
    public void playOGG(String filePath) {
        System.out.println("Playing OGG file: " + filePath);
    }

    // Method to play FLAC files
    public void playFLAC(String filePath) {
        System.out.println("Playing FLAC file: " + filePath);
    }

    public static void main(String[] args) {
        MediaPlayer player = new MediaPlayer();
        Scanner scanner = new Scanner(System.in);

        // Prompt the user for input
        System.out.println("Enter audio type (mp3, ogg, flac): ");
        String audioType = scanner.nextLine().toLowerCase();

        System.out.println("Enter file path: ");
        String filePath = scanner.nextLine();

        // Decide which method to call based on audio type
        switch (audioType) {
            case "mp3":
                player.playMP3(filePath);
                break;
            case "ogg":
                player.playOGG(filePath);
                break;
            case "flac":
                player.playFLAC(filePath);
                break;
            default:
                System.out.println("Unsupported audio format.");
                break;
        }

        scanner.close();
    }
}
