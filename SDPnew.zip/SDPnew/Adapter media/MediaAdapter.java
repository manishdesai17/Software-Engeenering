class MediaAdapter implements IMediaPlayer {
    private IAdvancedMediaPlayer advancedPlayer;

    public MediaAdapter(String audioType) {
        if (audioType.equalsIgnoreCase("ogg")) {
            advancedPlayer = new COGGPlayer();
        } else if (audioType.equalsIgnoreCase("flac")) {
            advancedPlayer = new CFLACPlayer();
        }
    }

    @Override
    public void play(String audioType, String fileName) {
        if (audioType.equalsIgnoreCase("ogg")) {
            advancedPlayer.playOGG(fileName);
        } else if (audioType.equalsIgnoreCase("flac")) {
            advancedPlayer.playFLAC(fileName);
        }
    }
}