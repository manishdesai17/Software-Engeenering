public abstract class SecurityHandler {
  protected SecurityHandler nextHandler;

  public void setNextHandler(SecurityHandler nextHandler) {
    this.nextHandler = nextHandler;
  }

  public abstract void handleRequest(UserRequest request);
}
