public class PermissionHandler extends SecurityHandler {
  @Override
  public void handleRequest(UserRequest request) {
    if ("read".equalsIgnoreCase(request.getPermission()) || "write".equalsIgnoreCase(request.getPermission())) {
      System.out.println("Permission granted: " + request.getPermission());
    } else {
      System.out.println("Permission denied: Invalid permission.");
    }
  }
}
