public class SecuritySystem {
  public static void main(String[] args) {
    // Create handlers
    SecurityHandler auth = new AuthenticationHandler();
    SecurityHandler roleCheck = new RoleCheckHandler();
    SecurityHandler permission = new PermissionHandler();

    // Set the chain
    auth.setNextHandler(roleCheck);
    roleCheck.setNextHandler(permission);

    // Create a request
    UserRequest request = new UserRequest("john", "admin", "write");

    // Start the chain
    auth.handleRequest(request);
  }
}
ya