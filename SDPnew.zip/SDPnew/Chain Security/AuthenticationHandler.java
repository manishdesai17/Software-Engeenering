public class AuthenticationHandler extends SecurityHandler {
  @Override
  public void handleRequest(UserRequest request) {
    if (request.getUsername() != null && !request.getUsername().isEmpty()) {
      System.out.println("Authentication successful for user: " + request.getUsername());
      if (nextHandler != null)
        nextHandler.handleRequest(request);
    } else {
      System.out.println("Authentication failed: Username is missing.");
    }
  }
}
