public class UserRequest {
  private String username;
  private String role;
  private String permission;

  public UserRequest(String username, String role, String permission) {
      this.username = username;
      this.role = role;
      this.permission = permission;
  }

  public String getUsername() {
      return username;
  }

  public String getRole() {
      return role;
  }

  public String getPermission() {
      return permission;
  }
}
