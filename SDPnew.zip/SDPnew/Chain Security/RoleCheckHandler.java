public class RoleCheckHandler extends SecurityHandler {
  @Override
  public void handleRequest(UserRequest request) {
    if ("admin".equalsIgnoreCase(request.getRole()) || "user".equalsIgnoreCase(request.getRole())) {
      System.out.println("Role verified: " + request.getRole());
      if (nextHandler != null)
        nextHandler.handleRequest(request);
    } else {
      System.out.println("Role check failed: Invalid role.");
    }
  }
}
