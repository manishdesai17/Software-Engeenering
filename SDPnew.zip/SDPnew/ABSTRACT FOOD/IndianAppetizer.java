public class IndianAppetizer extends Appetizer {
    @Override
    public String serve() {
        return "Serving Indian Appetizer: Samosa";
    }
}