public abstract class Appetizer {
    public abstract String serve();
}