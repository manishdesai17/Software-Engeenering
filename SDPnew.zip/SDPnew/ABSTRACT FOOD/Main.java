public class Main {
    public static void main(String[] args) {
        try {
            // Get Indian Factory
            AbstractFactory chinese = AbstractFactory.getFactory("chinese");
            MainCourse maincourse = chinese.getMainCourse();
            Appetizer Appetizer = chinese.getAppetizer();
            Dessert Dessert = chinese.getDessert();

            System.out.println(maincourse.serve());
            System.out.println(Appetizer.serve());
            System.out.println(Dessert.serve());
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
    }

}
