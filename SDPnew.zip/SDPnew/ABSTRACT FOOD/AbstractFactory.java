public abstract class AbstractFactory {
    public abstract MainCourse getMainCourse();

    public abstract Appetizer getAppetizer();

    public abstract Dessert getDessert();

    public static AbstractFactory getFactory(String dish) {
        switch (dish.toLowerCase()) {
            case "indian":
                return new IndianFactory();
            case "chinese":
                return new ChineseFactory();
            default:
                throw new IllegalArgumentException("Not Available in this type of dish: " + dish);
        }
    }
}