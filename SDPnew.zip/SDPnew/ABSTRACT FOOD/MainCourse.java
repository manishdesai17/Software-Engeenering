public abstract class MainCourse {
    public abstract String serve();
}