public class ChineseAppetizer extends Appetizer {
    public String serve() {
        return "Serving Chinese Appetizer: Spring Rolls";
    }
}
