public class ChineseMainCourse extends MainCourse {
    @Override
    public String serve() {
        return "Serving Chinese Main Course: Kung Pao Chicken";
    }
}
