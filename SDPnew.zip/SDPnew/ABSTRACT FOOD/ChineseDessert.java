public class ChineseDessert extends Dessert {
    @Override
    public String serve() {
        return "Serving Chinese Dessert: Mango Pudding";
    }
}