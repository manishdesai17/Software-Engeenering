public class IndianDessert extends Dessert {
    @Override
    public String serve() {
        return "Serving Indian Dessert: Gulab Jamun";
    }
}