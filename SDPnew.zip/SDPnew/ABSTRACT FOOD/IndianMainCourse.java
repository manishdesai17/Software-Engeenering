public class IndianMainCourse extends MainCourse {
    @Override
    public String serve() {
        return "Serving Indian Main Course: Butter Chicken";
    }
}