public abstract class Dessert {
    public abstract String serve();
}