public class PeaNut extends Additional {
    public PeaNut(IceCream nIceCream) {
        super(nIceCream);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " with PeaNut";
    }

    @Override
    public double getCost() {
        return super.getCost() + 100;
    }
}
