public class Vanilla implements IceCream {
    @Override
    public double getCost() {
        return 50;  // Base cost of vanilla ice cream
    }

    @Override
    public String getDescription() {
        return "Vanilla Ice Cream";
    }
}
