public interface IceCream {
    double getCost();
    String getDescription();
}
