public abstract class Additional implements IceCream {
    private IceCream nIceCream;

    public Additional(IceCream nIceCream) {
        this.nIceCream = nIceCream;
    }

    @Override
    public double getCost() {
        return nIceCream.getCost();
    }

    @Override
    public String getDescription() {
        return nIceCream.getDescription();
    }
}
