public class Main {
    public static void main(String[] args) {
        IceCream v1 = new Vanilla();
        System.out.println(v1.getDescription());
        System.out.println("Cost: " + v1.getCost());

        IceCream i1 = new CashewNut(new Vanilla());
        System.out.println(i1.getDescription());
        System.out.println("Cost: " + i1.getCost());

        IceCream i2 = new PeaNut(new Vanilla());
        System.out.println(i2.getDescription());
        System.out.println("Cost: " + i2.getCost());
    }
}
