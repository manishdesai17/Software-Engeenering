public class CashewNut extends Additional {
    public CashewNut(IceCream nIceCream) {
        super(nIceCream);
    }

    @Override
    public String getDescription() {
        return super.getDescription() + " with CashewNut";
    }

    @Override
    public double getCost() {
        return super.getCost() + 200;
    }
}
