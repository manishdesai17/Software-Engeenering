import java.sql.*;
public interface Database
{
   public void connect();
   
}