public class Main {
    public static void main(String[] args) {
        Notepad notepad;
		notepad = Notepad.getInstance();
		notepad = Notepad.getInstance();
        
    }
}