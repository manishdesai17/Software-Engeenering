public class Plastictable implements TableCellEditor
{
	public string placeon();
	{
		return "Plastic table";
	}
}