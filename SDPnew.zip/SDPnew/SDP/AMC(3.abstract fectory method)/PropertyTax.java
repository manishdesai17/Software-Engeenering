public interface PropertyTax
{
	public double propertyTax(double amount);
}