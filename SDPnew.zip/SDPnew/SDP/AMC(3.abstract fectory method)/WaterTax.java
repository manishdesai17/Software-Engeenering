public interface WaterTax
{
	public double waterTax(double amount);
}