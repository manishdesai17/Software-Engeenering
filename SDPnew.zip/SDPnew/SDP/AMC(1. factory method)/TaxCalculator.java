interface TaxCalculator
{
  public double billCalculate(double amount);
    
  public double getTaxAmount();
  
}