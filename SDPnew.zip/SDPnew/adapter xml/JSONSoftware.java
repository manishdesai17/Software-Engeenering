public class JSONSoftware implements JSONData 
{
	@Override
	public void readJSONData() 
	{
		// TODO Auto-generated method stub
		System.out.println("UNDERSTAND ONLY JSON DATA");
	}
}