public class XMLDataProvider {
  public String getXMLData() {
    return "<user><name>Ravi</name><age>25</age></user>";
  }
}
