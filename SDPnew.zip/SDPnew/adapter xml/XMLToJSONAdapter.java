public class XMLToJSONAdapter implements JSONDataTarget {

  private XMLDataProvider xmlProvider;

  public XMLToJSONAdapter(XMLDataProvider xmlProvider) {
    this.xmlProvider = xmlProvider;
  }

  @Override
  public String getJSONData() {
    // NOTE: Simple conversion (not real parsing)
    String xml = xmlProvider.getXMLData();
    String json = xml.replace("<user>", "{")
        .replace("</user>", "}")
        .replace("<name>", "\"name\": \"")
        .replace("</name>", "\", ")
        .replace("<age>", "\"age\": \"")
        .replace("</age>", "\"");
    return json;
  }
}
