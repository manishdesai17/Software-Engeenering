public class XMLSoftware implements XMLData 
{
	@Override
	public void readXMLData() 
	{
		// TODO Auto-generated method stub
		System.out.println("UNDERSTAND ONLY XML DATA");
	}
}