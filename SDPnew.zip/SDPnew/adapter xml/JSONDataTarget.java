public interface JSONDataTarget {
  String getJSONData();
}
