 public interface XMLData 
 {
	void readXMLData();
}