public class Main {
  public static void main(String[] args) {
    XMLDataProvider xmlProvider = new XMLDataProvider();
    JSONDataTarget adapter = new XMLToJSONAdapter(xmlProvider);

    System.out.println("JSON Output:");
    System.out.println(adapter.getJSONData());
  }
}
