public interface JSONData
{
	void readJSONData();
}